"""
Teams Chat Grabber package.

Copyright (C) 2025 Eric C. Mumford (@heymumford)
MIT License
"""
